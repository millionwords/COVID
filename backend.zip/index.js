const express = require('express');
const request = require("request");
var multer  = require('multer');
const mongoose = require('mongoose');
var {spawn, exec} = require('child_process')
//var lineReader = require('line-reader');
const { v4: uuidv4 } = require('uuid');
var fs = require('fs');
let Result = require('./models/Result');
let Survey = require('./models/Survey');
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads/')
  },
  filename: function (req, file, cb) {
    console.log(file);
	let name = file.originalname.split(".");
	let filename = "file."+name[name.length-1];
	console.log(name);
	console.log(filename);
    cb(null, filename) //Appending extension
  }
})

var upload = multer({ storage : storage }).single('file');
var bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config()

var corsOptions = {
    origin: '*',
    credentials:  true,
  }

  


const app = express();

app.use(bodyParser.json());

app.use(express.json());

app.use(cors(corsOptions));

app.use(bodyParser.urlencoded({extended: true}));

const port = process.env.PORT || 8000;


app.use(function (req, res, next) {

  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin', 'http://45.63.126.171:3002');

  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader('Access-Control-Allow-Credentials', true);

  // Pass to next layer of middleware
  next();
});

mongoose.connect(process.env.MONGODB_URI,{ useFindAndModify: false,
  useCreateIndex: true,
  useUnifiedTopology: true,
  useNewUrlParser: true })
  .then(() => console.log('Connected to MongoDB...'))
  .catch(err => console.error('Could not connect to MongoDB...' + err));

  function base64_encode(file) {
    // read binary data
    var bitmap = fs.readFileSync(file);
    // convert binary data to base64 encoded string
    return new Buffer(bitmap).toString('base64');
}

app.post('/upload', async function(req, res) {
  upload(req, res, function(err) {
    if(err) {
      console.log('Error Occured' + err);
      return res.status(400).json({result: "error"});
      }
    console.log(req.file);
    console.log('Photo Uploaded');
    var base64str = base64_encode(req.file.path);
    //console.log(base64str);
    child = exec(`python3 script.py -i ${req.file.path}`,async function (error, stdout, stderr){
      console.log('stdout: ' + stdout);
      if (error !== null) {
        console.log('exec error: ' + error);
        return res.status(400).json({result: "error"});
        }
        let id=uuidv4();
        let result = new Result({
          resultId: id,
          result: stdout,
          image: base64str,
          extension: req.file.mimetype,
          createdAt: Date.now()
        });
        await result.save();
        try {
          fs.unlinkSync(req.file.path);
          //file removed
		console.log("file removed");
        } catch(err) {
          console.error(err)
        }
         return res.status(200).json({result: id});
      });
  })

});

app.post('/survey', async function(req, res) {
  console.log(req.body);
  let survey = new Survey({
    name: req.body.survey1.full_name,
    age: req.body.survey1.age,
    location: req.body.survey1.location,
    email: req.body.survey1.email,
    phoneNo: req.body.survey1.phone,
    question1: req.body.survey2.question1,
    question2: req.body.survey2.question2,
    question3: req.body.survey2.question3,
    question4: req.body.survey2.question4||null,
    createdAt: Date.now()
  });
  await survey.save();
  return res.status(400).json({result: "success"});
})

app.get('/getResult/:id', async function(req, res) {
  console.log(req.params.id+" here");
  let result;
  try{
     result = await Result.findOne({resultId: req.params.id});
     if(!result){
       return res.status(404).json({result: "not found"});
     }
  }
  catch(err){
    return res.status(400).json({result: "something went wrong"});
  }
  return res.status(200).json({result: result});
})

app.get('/getInfo', async function(req, res){
  request.get('https://api.coronatracker.com/v3/stats/worldometer/country?countryCode=IN', function(err, data){
    // console.log(err);
    console.log(data.body);
    if(err){
      console.log(err);
      return res.status(400).json({result: "error"});
    }
    return res.status(200).json(JSON.parse(data.body));
  })
})

app.get('/getUpdates', async function(req, res){
  request.get('https://api.covid19india.org/updatelog/log.json', function(err, data){
   // console.log(err);
   // console.log(data.body);
    if(err){
      console.log(err);
      return res.status(400).json({result: "error"});
    }
    return res.status(200).json(JSON.parse(data.body));
  })
})

app.listen(port, () => console.log(`Listening on port ${port}...`));

