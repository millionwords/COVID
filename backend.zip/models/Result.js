const mongoose = require('mongoose');

let ResultSchema = new mongoose.Schema({
  resultId:{
    required: true,
    type: String
  },
  image: {
    type: String,
    required: true
  },
  result: {
    type: String,
    required: true
  },
  extension: {
    type: String,
    required: true
  },
  createdAt: {
    type: Number,
    required: true
  }
});

//const User = mongoose.model('User', UserSchema);


ResultSchema = mongoose.model('Result', ResultSchema);



module.exports = ResultSchema; 