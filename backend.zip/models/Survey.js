const mongoose = require('mongoose');

let SurveySchema = new mongoose.Schema({
  name:{
    required: true,
    type: String
  },
  age: {
    type: Number,
    required: true
  },
  location: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  phoneNo: {
    type: Number,
    required: true
  },
  createdAt: {
    type: Number,
    required: true
  },
  question1: {
    type: String,
    required: true
  },
  question2: {
    type: String,
    required: true
  },
  question3: {
    type: String,
    required: true
  },
  question4: {
    type: String
  }
});

//const User = mongoose.model('User', UserSchema);


SurveySchema = mongoose.model('Survey', SurveySchema);



module.exports = SurveySchema; 