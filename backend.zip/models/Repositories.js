const mongoose = require('mongoose');

let RepositoriesSchema = new mongoose.Schema({
  name:{
    required: true,
    type: String
  },
  host: {
    required: true,
    type: String
  },
  lastUpdated: {
    type: Number
  }
});

//const User = mongoose.model('User', UserSchema);


RepositoriesSchema = mongoose.model('Buser', RepositoriesSchema);



module.exports = RepositoriesSchema; 